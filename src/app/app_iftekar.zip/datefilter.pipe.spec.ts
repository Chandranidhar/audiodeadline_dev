import { DatefilterPipe } from './datefilter.pipe';

describe('DatefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DatefilterPipe();
    expect(pipe).toBeTruthy();
  });
});
