import { BannerfiltertextPipe } from './bannerfiltertext.pipe';

describe('BannerfiltertextPipe', () => {
  it('create an instance', () => {
    const pipe = new BannerfiltertextPipe();
    expect(pipe).toBeTruthy();
  });
});
